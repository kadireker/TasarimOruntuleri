﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentUMLDiagram
{
    public class Student : Person
    {
        public int? Grade = 0;
        public char? GradeLetter = 'F';
        public int GraduationYear;
        public static int StudentCount = 0;
        private Person pp;
        public Course cc;

        public Student(Person pp, int Grade, char GradeLetter, int GraduationYear)
        {
            Name = pp.Name;
            Id = pp.Id;
            Age = pp.Age;
            this.pp = pp;
            this.Grade = Grade;
            this.GradeLetter = GradeLetter;
            this.GraduationYear = GraduationYear;
        }

        public Student()
        {

        }

        public Student(Person pp)
        {
            this.pp = pp;
        }

        public void AddCourse(Course c)
        {
            cc = c;
        }

        public void AddSemester(Semester sm)
        {
            Console.WriteLine(pp.Name + " - " + sm.SemesterName + " Semester Eklendi");
        }
        public virtual void DisplayList(List<Student> stList)
        {
            foreach (var item in stList)
            {
                Console.WriteLine("ID:" + item.Id + "\n" + "Adı:"
                    + item.Name + "\n" + item.Age +
                    "\n" + "Notu: " + item.Grade + "\n" + "NotHarf: " + item.GradeLetter);
            }

        }

        public static void CountStudentList(List<Student> stList)
        {
            StudentCount = stList.Count;
            Console.WriteLine("Öğrenci Sayısı : " + StudentCount);
        }
        public void CallByValue(List<Student> stList, string Id)
        {
            var item = stList.Where(s => s.Id == Id) == null ? new List<Student>() : stList.Where(s => s.Id == Id).OrderBy(a => a.Name).ToList();
            Console.WriteLine("ID:" + item.FirstOrDefault().Id + "\n" + "Adı:"
                    + item.FirstOrDefault().Name + "\n" + item.FirstOrDefault().Age +
                    "\n" + "Notu: " + item.FirstOrDefault().Grade + "\n" + "NotHarf: " + item.FirstOrDefault().GradeLetter);
        }

        public void AddPartner(Student p) => AddPartner(this);
        public void ShiftClassSchedule(Student p) => ShiftClassSchedule(this);

    }
}
