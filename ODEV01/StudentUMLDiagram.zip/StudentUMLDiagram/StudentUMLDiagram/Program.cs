﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentUMLDiagram
{
    public abstract class Person
    {
        public string Id;
        public string Name;
        public int Age;
    }

    public class Program
    {
        static void Main(string[] args)
        {
            Semester sm = new Semester("Bahar", DateTime.Now, DateTime.Now.AddMonths(4));
            Course cc = new Course();
            cc.Title = "Mat";
            cc.grade = 50;

            List<Student> st = new List<Student>();
        
            Person pp = new Student();
            pp.Id = "123";
            pp.Name = "Kadir EKER";
            pp.Age = 32;
            st.Add(new Student(pp, 85, 'B', 2022));
            Person pp2 = new Student();
            pp2.Id = "124";
            pp2.Name = "Melike EKER";
            pp2.Age = 20;
            st.Add(new Student(pp2,80,'A',2020));
            
            foreach (var item in st)
            {
                item.AddSemester(sm);
                item.AddCourse(cc);
            }
            cc.DisplayList(st);
            Console.ReadLine();
        }
    }
}
