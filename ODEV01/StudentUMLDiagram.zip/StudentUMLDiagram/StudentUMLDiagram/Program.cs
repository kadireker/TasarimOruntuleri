﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentUMLDiagram
{
    public abstract class Person
    {
        public string Id;
        public string Name;
        public int Age;
    }

    public class Student : Person
    {
        public int? Grade = 0;
        public char? GradeLetter = 'F';
        public int GraduationYear;
        public static int StudentCount = 0;
        private Person pp;
        public Course cc;

        public Student(Person pp,int Grade,char GradeLetter,int GraduationYear)
        {
            Name = pp.Name;
            Id = pp.Id;
            Age = pp.Age;
            this.pp = pp;
            this.Grade = Grade;
            this.GradeLetter = GradeLetter;
            this.GraduationYear = GraduationYear;
        }

        public Student()
        {
            
        }

        public Student(Person pp)
        {
            this.pp = pp;
        }

        public void AddCourse(Course c)
        {
            cc = c;
        }

        public void AddSemester(Semester sm)
        {
            Console.WriteLine(pp.Name + " - " + sm.SemesterName + " Semester Eklendi");
        }
        public virtual void DisplayList(List<Student> stList)
        {
            foreach (var item in stList)
            {
                Console.WriteLine("ID:" + item.Id + "\n" + "Adı:"
                    + item.Name + "\n" + item.Age +
                    "\n" + "Notu: " + item.Grade + "\n" + "NotHarf: " + item.GradeLetter);
            }

        }

        public static void CountStudentList(List<Student> stList)
        {
            StudentCount = stList.Count;
            Console.WriteLine("Öğrenci Sayısı : " + StudentCount);
        }
        public void CallByValue(List<Student> stList,string Id)
        {
            var item = stList.Where(s => s.Id == Id)==null?new List<Student>(): stList.Where(s => s.Id == Id).OrderBy(a => a.Name).ToList();
            Console.WriteLine("ID:" + item.FirstOrDefault().Id + "\n" + "Adı:"
                    + item.FirstOrDefault().Name + "\n" + item.FirstOrDefault().Age +
                    "\n" + "Notu: " + item.FirstOrDefault().Grade + "\n" + "NotHarf: " + item.FirstOrDefault().GradeLetter);
        }

        public void AddPartner(Student p) => AddPartner(this);
        public void ShiftClassSchedule(Student p) => ShiftClassSchedule(this);

    }
    public class Semester : Student
    {
        public string SemesterName;
        public DateTime startDate;
        public DateTime endDate;

        public Semester(string semesterName, DateTime startDate, DateTime endDate)
        {
            SemesterName = semesterName;
            this.startDate = startDate;
            this.endDate = endDate;
        }

        public void DisplayList(Semester sm)
        {
            Console.WriteLine("Semester Display");
        }
    }
    public class Course : Student
    {
        public string Title;
        public double grade;
        public override void DisplayList(List<Student> stList)
        {
            Console.WriteLine();
            Console.WriteLine("Alınan Dersler");
            stList.Sort();
            foreach (var item in stList)
            {           
                Console.WriteLine(item.Name);
                Console.WriteLine( "Kurs Adı:"+ item.cc.Title + "\n" +"Kurs Geçme Notu: " + item.cc.grade+ "\n");
                Console.WriteLine();
            }
        }
       
    }

    public class Holiday : Student
    {
        public string HolidayName;
        public DateTime HolidaystartDate;
        public DateTime HolidayendDate;
        public bool shiftSchedule;

        public Holiday(string holidayName, DateTime holidaystartDate, DateTime holidayendDate, bool shiftSchedule)
        {
            HolidayName = holidayName;
            HolidaystartDate = holidaystartDate;
            HolidayendDate = holidayendDate;
            this.shiftSchedule = shiftSchedule;
        }

        public virtual void DisplayList(Semester sm) => DisplayList(this);

        private void DisplayList(Holiday holiday)
        {
            Console.WriteLine("Holiday Display");

        }
    }


    public class Program
    {
        static void Main(string[] args)
        {
            Semester sm = new Semester("Bahar", DateTime.Now, DateTime.Now.AddMonths(4));
            Course cc = new Course();
            cc.Title = "Mat";
            cc.grade = 50;

            List<Student> st = new List<Student>();
        
            Person pp = new Student();
            pp.Id = "123";
            pp.Name = "Kadir EKER";
            pp.Age = 32;
            st.Add(new Student(pp, 85, 'B', 2022));
            Person pp2 = new Student();
            pp2.Id = "124";
            pp2.Name = "Melike EKER";
            pp2.Age = 20;
            st.Add(new Student(pp2,80,'A',2020));
            
            foreach (var item in st)
            {
                item.AddSemester(sm);
                item.AddCourse(cc);
            }
            cc.DisplayList(st);
            Console.ReadLine();
        }
    }
}
