﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentUMLDiagram
{
    public class Course : Student
    {
        public string Title;
        public double grade;
        public override void DisplayList(List<Student> stList)
        {
            Console.WriteLine();
            Console.WriteLine("Alınan Dersler");
            foreach (var item in stList)
            {
                Console.WriteLine(item.Name);
                Console.WriteLine("Kurs Adı:" + item.cc.Title + "\n" + "Kurs Geçme Notu: " + item.cc.grade + "\n");
                Console.WriteLine();
            }
        }

    }
}
