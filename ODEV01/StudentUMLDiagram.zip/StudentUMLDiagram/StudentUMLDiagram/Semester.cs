﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentUMLDiagram
{
    public class Semester : Student
    {
        public string SemesterName;
        public DateTime startDate;
        public DateTime endDate;

        public Semester(string semesterName, DateTime startDate, DateTime endDate)
        {
            SemesterName = semesterName;
            this.startDate = startDate;
            this.endDate = endDate;
        }

        public void DisplayList(Semester sm)
        {
            Console.WriteLine("Semester Display");
        }
    }
}
