﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentUMLDiagram
{
    public class Holiday : Student
    {
        public string HolidayName;
        public DateTime HolidaystartDate;
        public DateTime HolidayendDate;
        public bool shiftSchedule;

        public Holiday(string holidayName, DateTime holidaystartDate, DateTime holidayendDate, bool shiftSchedule)
        {
            HolidayName = holidayName;
            HolidaystartDate = holidaystartDate;
            HolidayendDate = holidayendDate;
            this.shiftSchedule = shiftSchedule;
        }

        public virtual void DisplayList(Semester sm) => DisplayList(this);

        private void DisplayList(Holiday holiday)
        {
            Console.WriteLine("Holiday Display");

        }
    }
}
